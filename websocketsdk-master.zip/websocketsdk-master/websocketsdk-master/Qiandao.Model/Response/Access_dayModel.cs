﻿
namespace Qiandao.Model.Response
{
    public class Access_dayModel
    {
        public required int Id { get; set; }

        public required string Serial { get; set; }

        public required string Name { get; set; }

        public string? Start_time1 { get; set; }

        public string? End_time1 { get; set; }

        public string? Start_time2 { get; set; }

        public string? End_time2 { get; set; }

        public string? Start_time3 { get; set; }

        public string? End_time3 { get; set; }

        public string? Start_time4 { get; set; }

        public string? End_time4 { get; set; }

        public string? Start_time5 { get; set; }

        public string? End_time5 { get; set; }
    }
}
