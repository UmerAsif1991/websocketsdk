﻿
namespace Qiandao.Model.Response
{
    public class PersonModel
    {
        public required long Id { get; set; }

        public required string Name { get; set; }

        public required int Roll_id { get; set; }
    }
}
