﻿
namespace Qiandao.Model.Entity
{
    public class Person
    {
        public long? Id { get; set; }

        public required string Name { get; set; }

        public  int? Roll_id { get; set; }
    }
}
