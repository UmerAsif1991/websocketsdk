﻿
namespace Qiandao.Model.Entity
{
    public class Access_day
    {
        public  int? Id { get; set; }

        public  string? Serial { get; set; }

        public  string? Name { get; set; }

        public required string start_time1 { get; set; }

        public required string end_time1 { get; set; }

        public required string start_time2 { get; set; }

        public required string end_time2 { get; set; }

        public required string start_time3 { get; set; }

        public required string end_time3 { get; set; }

        public required string start_time4 { get; set; }

        public required string end_time4 { get; set; }

        public required string start_time5 { get; set; }

        public required string end_time5 { get; set; }
    }
}
