﻿
namespace Qiandao.Model.Entity
{
   public class UserTemp
    {
        public long enrollId { set; get; }
        public int admin { set; get; }
        public int backupnum { set; get; }
    }
}
