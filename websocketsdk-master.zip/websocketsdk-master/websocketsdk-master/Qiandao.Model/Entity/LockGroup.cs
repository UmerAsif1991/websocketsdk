﻿
namespace Qiandao.Model.Entity
{
  public  class LockGroup
    {
        public string group1 { get; set; }
        public string group2 { get; set; }
        public string group3 { get; set; }
        public string group4 { get; set; }
        public string group5 { get; set; }
    }
}
