﻿using System;

namespace Qiandao.Service
{
    public interface IScope : IDisposable
    {
        // 可以在这里定义一些通用的方法或者属性
    }
}